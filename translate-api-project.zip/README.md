# Translate API

API penerjemah sederhana dengan Google Translate API unofficial.